#!/bin/bash
#SBATCH --export=NONE                #Do not propagate environment
#SBATCH --get-user-env=L             #Replicate login environment

##NECESSARY JOB SPECIFICATIONS
#SBATCH --job-name=poisson       #Set the job name to "JobExample1"
#SBATCH --time=01:30:00              #Set the wall clock limit to 1hr and 30min
#SBATCH --nodes=1                    #Request 1 node
#SBATCH --ntasks-per-node=4          #Request 8 tasks/cores per node
#SBATCH --mem=2560M                 #Request 2560MB (2.5GB) per node
#SBATCH --output=poisson.%j      #Send stdout/err to "Example1Out.[jobID]"

module load intel/2018b
mpirun ./poisson-mpi.exe <<BEGIN
800
100000000
BEGIN
