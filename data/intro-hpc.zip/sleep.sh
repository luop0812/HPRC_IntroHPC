#!/bin/bash
#SBATCH --job-name=test_script
#SBATCH --time=00:00:30
#SBATCH --ntasks=8
#SBATCH --ntasks-per-node=2
#SBATCH --mem=2560M
#SBATCH --output=test.out

echo 'This script is running on:'
hostname
echo 'The date is :'
date
sleep 120
